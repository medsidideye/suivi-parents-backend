import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# En développement : SQLite local. En production : remplacer par une URL PostgreSQL,
# ex. postgresql://user:password@host:5432/nom_base
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./suivi_parents.db")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
